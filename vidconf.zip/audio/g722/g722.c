#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define FRMSZ 160
#define SIGN(a) ( ( (a) < 0.0 ) ? -1 : 1 )

/*
 * This program implements the CCITT's G.722 standard coder for wideband speech.
 *
 *
 * References :
 *
 * X. Maitre, "7kHz Audio Coding Within 64 kbit/s", IEEE Journal on
 * Selected areas in Communications, February 1988.
 */

/* split, merge coefficients  */
static const float     cof[24] = 
                        {  0.366211E-03,  -0.134277E-02, 
                          -0.134277E-02,   0.646973E-02, 
                           0.146484E-02,  -0.190430E-01,
                           0.390625E-02,   0.441895E-01,
                          -0.256348E-01,  -0.982666E-01, 
                           0.1160893E+00,  0.473145E+00,
                           0.473145E+00,   0.1160893E+00,
                          -0.982666E-01,  -0.256348E-01, 
                           0.441895E-01,   0.390625E-02,
                          -0.190430E-01,   0.146484E-02, 
                           0.646973E-02,  -0.134277E-02,
                          -0.134277E-02,   0.366211E-03   };


int main( void )
{
   FILE            *input, *output;
   float           speech[FRMSZ], signal[FRMSZ], low[FRMSZ/2], up[FRMSZ/2];
   float           n_energy, s_energy, snr;
   int             i, j, nofrms, mode;

   int initialise( FILE **, FILE **, int * );

   void code_low( float *, int );
   void code_up( float * );
   void new_frame( FILE *, float * );
   void qmf_split( float *, float *, float * );
   void qmf_merge( float *, float *, float * );

   if( (input = (FILE *)malloc( sizeof(FILE) )) == NULL )
   {
      printf("Not enough memory for file pointer one!");
      exit(EXIT_FAILURE);
   }
   if((output = (FILE *)malloc( sizeof(FILE) )) == NULL )
   {
      printf("Not enough memory for file pointer two!");
      exit(EXIT_FAILURE);
   }

   nofrms = initialise( &input, &output, &mode );

   snr = 0.0;
   for( i=0; i<nofrms; i++ )
   {
      if( ( i+1 % 10 ) == 0 ) 
         printf("\nFrame %d of %d",i+1,nofrms);

      new_frame( input, speech );
      for( j=0; j<FRMSZ; j++ )
	 signal[j] = speech[j];

      qmf_split(speech, low, up );

      code_low( low, mode );
      code_up( up );

      qmf_merge( low, up, speech );

      s_energy = n_energy = 0.0;
      for( j=0; j<FRMSZ; j++ )
      {
	 s_energy += signal[j] * signal[j];
	 n_energy = ( signal[j] - speech[j] ) * ( signal[j] - speech[j] );
      }
      snr += 10 * log10( s_energy / n_energy ) / (float)nofrms;

      for( j=0; j<FRMSZ; j++ )
	 fprintf(output,"%f\n", speech[j] );
   }

   printf("\n\nThe Segmental SNR is %fdB\n\n",snr);

   fclose( input );
   fclose( output );

   return 0;
}


/*
 * This function initialises the coder.
 */

int initialise( FILE **input, FILE **output, int *mode )
{
   const int       bit_rates[3] = { 48, 56, 64 };
   short int       buffer[1000];
   long int        count;
   int             i;
   char            name[80];
				 
   FILE *openfile( FILE *, char *, int );

   printf("\nEnter the name of the input file (binary) ... \n");
   scanf("%s",name);
   *input = openfile( *input, name, 0 );
   printf("\nEnter the name of the output file (ascii) ... \n");
   scanf("%s",name);
   *output = openfile( *output, name, 1 );

   count = 0;
   while( ( i = fread(buffer,sizeof(short),1000,*input) ) > 0 )
      count += i;
   count /= FRMSZ;
   rewind( *input );

   printf("\n\nThere are three modes of operation.");
   printf("\n\tMode 1 = 48 kb/s\n\tMode 2 = 56 kb/s\n\tMode 3 = 64 kb/s");
   printf("\nEnter the mode to use ...\n");
   scanf("%d",mode);
   printf("\n\nThere are %d frames in the input file.", count );
   printf("\nEnter the number of frames to process ...\n");
   scanf("%d", &i );

   i = ( i > count ) ? count : i;

   printf("\n\nWill process %d frames at %d kb/s.\n", i, bit_rates[*mode-1] );

   return( i );
}


/*
 * This function opens a file.  The name of the file and its path
 * is contained in the string "name". Two kinds of file can be opened,
 * namely a read only binary file and a output ascii file.
 */

FILE *openfile( FILE *fileptr, char name[], int rw )
{
   int             fail;
   char            choice[5];

   do
   {
      fail = 0;
      if( rw == 0 )
      {
	 if( ( fileptr=fopen( name, "rb" ) ) == NULL )
	    fail = 1;
      }
      else
      {
	 if( ( fileptr=fopen( name, "w" ) ) == NULL )
	    fail = 1;
      }

      if( fail == 1 )
      {
	 printf("\nError in opening the file ...\n%s\n", name );
	 printf("Do you want to end the program (y/n) ... ");
	 scanf("%s", choice );
	 if( ( choice[0] == 'y' ) || ( choice[0] == 'Y' ) )
	    exit(EXIT_FAILURE);
	 else
	 {
	    printf("\nEnter the name of the file ...\n");
	    scanf("%s", name );
	 }
      }
   }
   while( fail == 1 );

   return( fileptr );
}


/*
 * This function reads in a block of speech.
 */

void new_frame( FILE *fileptr, float speech[] )
{
   short int       buffer[FRMSZ];
   int             i;

   if( fread(buffer,sizeof(short),FRMSZ,fileptr) < FRMSZ )
   {
      printf("\n\nError in inputting the data!\n");
      exit(EXIT_FAILURE);
   }

   for( i=0; i<FRMSZ; i++ )
      speech[i] = (float)buffer[i];

   return;
}


/*
 * This function splits the sheech input into two equall sub-bands using
 * a QMF bank. The QMF's are realised using a polyphase structure.
 * The input is sampled at 16kHz and both output bands are sampled at 8kHz.
 */

void qmf_split( float in[], float low[], float up[] )
{
   static float    memory[FRMSZ+24-1] = {0.0};
   float           compute_up, compute_low;
   int             i, j;

   for( i=0; i<23; i++ )        /* Update the memory. */
      memory[i] = memory[i+FRMSZ];

   for( i=0; i<FRMSZ; i++ )
      memory[23+i] = in[i];

   for( j=0; j<FRMSZ; j++ )
      {
      compute_up = compute_low = 0.0;
      for( i=0; i<12; i++ )
         {
         compute_low += cof[2*i] * memory[23+2*j-(2*i)];
         compute_up += cof[(2*i)+1] * memory[23+2*j-(2*i)-1];
         }

      up[j] = compute_low - compute_up;
      low[j] = compute_low + compute_up;
      }

   return;
}


void code_low( float speech[], int mode )
{
   const float     levels_64[30] = { 0.0, 0.06817, 0.14103, 0.21389,
				     0.29212, 0.37035, 0.45482, 0.53929,
				     0.63107, 0.72286, 0.82335, 0.92383,
				     1.03485, 1.14587, 1.26989, 1.39391,
				     1.53439, 1.67486, 1.83683, 1.99880,
				     2.19006, 2.38131, 2.61482, 2.84833,
				     3.14822, 3.44811, 3.86796, 4.28782,
				     4.99498, 5.70214 };
   const float     levels_56[15] = { 0.0, 0.14103, 0.29212, 0.45482,
				     0.63107, 0.82335, 1.03485, 1.26989,
				     1.53439, 1.83683, 2.19006, 2.61482,
				     3.14822, 3.86796, 4.99498 };
   const float     levels_48[8] = { 0.0, 0.14103, 0.45482, 0.82335,
				    1.26989, 1.83683, 2.61482, 3.86796 };
   const float     recon_64[30] = { 0.03409, 0.10460, 0.17746, 0.25300,
				    0.33124, 0.41259, 0.49706, 0.58518,
				    0.67697, 0.77310, 0.87359, 0.97934,
				    1.09036, 1.20788, 1.33191, 1.46415,
				    1.60462, 1.75585, 1.91782, 2.09443,
				    2.28568, 2.49806, 2.73157, 2.99827,
				    3.29816, 3.65804, 4.07789, 4.64140,
				    5.34856, 6.05572 };
   const float     recon_56[15] = { 0.06817, 0.21389, 0.37035, 0.53929,
				    0.72286, 0.92383, 1.14587, 1.39391,
				    1.67486, 1.99880, 2.38131, 2.84833,
				    3.44811, 4.28782, 5.70214 };
   const float     recon_48[8] = { 0.0, 0.29212, 0.63107, 1.03485, 1.53439,
				2.19006, 3.14822, 4.99498 };
   const float     weights[8] = { -0.02930, -0.01465, 0.02832, 0.08398,
				  0.16309, 0.26270, 0.58496, 1.48535 };
   static float    a[2] = {0.0}, b[6] = {0.0}, resid[7] = {0.0}, scale = 1.0;
   float           estimate, zero;
   int             i, j, index, long_index, sign;

   void update_predictor( float *, float *, float *, float, int );
   float predict_low( float *, float *, float *, float * );
   float update_quantiser_low( float *, int, float );
   int quantise( float *, int, float, float );

   for( i=0; i<FRMSZ/2; i++ )
   {
      estimate = predict_low( a, b, resid, &zero );
      speech[i] -= estimate;
      sign = SIGN( speech[i] );
      index = quantise( (float *)levels_48, 8, scale, speech[i] );
      if( mode == 2 )
	 long_index = quantise( (float *)levels_56, 15, scale, speech[i] );
      if( mode == 3 )
	 long_index = quantise( (float *)levels_64, 30, scale, speech[i] );

      for( j=1; j<7; j++ )
	 resid[j-1] = resid[j];
      resid[6] = recon_48[index] * scale * (float)sign;

      speech[i] = estimate;
      if( mode == 1 )
	 speech[i] += resid[6];
      else
      {
	 if( mode == 2 )
	    speech[i] += recon_56[long_index] * scale * (float)sign;
	 else
	    speech[i] += recon_64[long_index] * scale * (float)sign;
      }

      update_predictor( a, b, resid, zero, 0 );
      scale = update_quantiser_low( (float *)weights, index, scale );
   }

   return;
}


void code_up( float speech[] )
{
   const float     levels[2] = { 0.0, 1.10156 };
   const float     recon[2] = { 0.39453, 1.80859 };
   const float     weights[2] = { -0.10449, 0.38965 };
   static float    a[2] = {0.0}, b[6] = {0.0}, resid[7] = {0.0}, scale = 1.0;
   float           estimate, zero;
   int             i, j, index, sign;

   void update_predictor( float *, float *, float *, float, int );
   float predict_up( float *, float *, float *, float * );
   float update_quantiser_up( float *, int, float );
   int quantise( float *, int, float, float );

   for( i=0; i<FRMSZ/2; i++ )
   {
      estimate = predict_up( a, b, resid, &zero );
      speech[i] -= estimate;
      sign = SIGN( speech[i] );
      index = quantise( (float *)levels, 2, scale, speech[i] );

      for( j=1; j<7; j++ )
	 resid[j-1] = resid[j];
      resid[6] = recon[index] * scale * (float)sign;
      speech[i] = estimate + resid[6];

      update_predictor( a, b, resid, zero, 1 );
      scale = update_quantiser_up( (float *)weights, index, scale );
   }

   return;
}


/*
 * This function predicts the value of a speech sample in the lower band.
 */

float predict_low( float a[], float b[], float resid[], float *zero )
{
   static float    estimate = 0.0, synth[2] = {0.0};
   int             i;

   synth[0] = synth[1];
   synth[1] = estimate + resid[6];

   *zero = 0.0;
   for( i=0; i<6; i++ )
      *zero += b[i] * resid[6-i];

   estimate = a[0] * synth[1] + a[1] * synth[0] + *zero;

   return( estimate );
}


/*
 * This function  predicts the value of a speech sample in the upper band.
 */

float predict_up( float a[], float b[], float resid[], float *zero )
{
   static float    estimate = 0.0, synth[2] = {0.0};
   int             i;

   synth[0] = synth[1];
   synth[1] = estimate + resid[6];

   *zero = 0.0;
   for( i=0; i<6; i++ )
      *zero += b[i] * resid[6-i];

   estimate = a[0] * synth[1] + a[1] * synth[0] + *zero;

   return( estimate );
}


/*
 * This function quantises the residual in the log ( base 2 ) domain.
 */

int quantise( float levels[], int no_levels, float scale, float sample )
{
   int             i, index, next;

   sample = fabs( sample ) / scale;

   i = 1;
   next = 1;
   index = no_levels-1;
   do
   {
      if( sample < levels[i] )
      {
	 next = 0;
	 index = i-1;
      }
   }
   while( ( next == 1 ) && ( ++i < no_levels-1 ) );

   return( index );
}


/*
 * This function updates the predictor.
 */

void update_predictor( float a[], float b[], float resid[], float zero, int band )
{
   static float    p_l[3] = {0.0}, p_u[3] = {0.0};
   float           p[3], f;
   int             i, pa, pb;

   if( band == 0 )
   {
      p[0] = p_l[0];
      p[1] = p_l[1];
      p[2] = p_l[2];
   }
   else
   {
      p[0] = p_u[0];
      p[1] = p_u[1];
      p[2] = p_u[2];
   }

   p[0] = p[1];
   p[1] = p[2];
   p[2] = zero + resid[6];

   f = ( fabs( a[0] ) > 0.5 ) ? 2.0 * SIGN( a[0] ) : 4.0 * a[0];

   pa = SIGN( p[2] ) * SIGN( p[1] );
   pb = SIGN( p[2] ) * SIGN( p[0] );
   a[1] = 0.9921875 * a[1] + 0.0078125 * ( (float)pb - f*(float)pa );
   a[0] = 0.99609375 * a[0] + 0.01171875 * (float)pa;

   a[1] = ( fabs( a[1] ) > 0.75 ) ? SIGN(a[1]) * 0.75 : a[1];
   a[0] = ( fabs( a[0] ) > ( 0.9375-a[1] ) ) ? ( 0.9375-a[1] )*SIGN(a[0]) : a[0];

   for( i=0; i<6; i++ )
   {
      b[i] = 0.99609375 * b[i];
      if( resid[6] != 0.0 )
	 b[i] += 0.0078125*SIGN(resid[6])*SIGN(resid[5-i]);
      b[i] = ( fabs( b[i] ) > 2.0 ) ? 2.0*SIGN(b[i]) : b[i];
   }

   if( band == 0 )
   {
      p_l[0] = p[0];
      p_l[1] = p[1];
      p_l[2] = p[2];
   }
   else
   {
      p_u[0] = p[0];
      p_u[1] = p[1];
      p_u[2] = p[2];
   }

   return;
}


/*
 * This function updates the adaptive quantiser in the lower band.
 */

float update_quantiser_low( float weights[], int index, float scale )
{
   const float     delta_min = 1.0;
   static float    log_scale = 0.0;
   static int      old_index = 0.0;

   log_scale = ( 127.0/128.0 ) * log_scale + weights[old_index];
   log_scale = ( log_scale < 0.0 ) ? 0.0 : log_scale;
   log_scale = ( log_scale > 9.0 ) ? 9.0 : log_scale;

   old_index = index;

   scale = pow( 2.0, ( log_scale + 2.0 ) ) * delta_min;

   return( scale );
}


/*
 * This function updates the adaptive quantiser in the upper band.
 */

float update_quantiser_up( float weights[], int index, float scale )
{
   const float     delta_min = 1.0;
   static float    log_scale = 0.0;
   static int      old_index = 0.0;

   log_scale = ( 127.0/128.0 ) * log_scale + weights[old_index];
   log_scale = ( log_scale < 0.0 ) ? 0.0 : log_scale;
   log_scale = ( log_scale > 11.0 ) ? 11.0 : log_scale;

   old_index = index;

   scale = pow( 2.0, log_scale ) * delta_min;

   return( scale );
}


/*
 * This function merges the two sub-bands using the QMF technique.
 * The QMF's are realised using a polyphase structure. Both the inputs
 * are sampled at 8kHz and the output is sampled at 16kHz.
 */

void qmf_merge( float low[], float up[], float out[] )
{
   static float    mlow[((FRMSZ+24)/2)-1]={0.0}, mup[((FRMSZ+24)/2)-1]={0.0};
   int             i, j, n;

   for( i=0; i<11; i++ )        /* Update the memory. */
   {
      mlow[i] = mlow[i+(FRMSZ/2)];
      mup[i] = mup[i+(FRMSZ/2)];
   }
   for( i=0; i<FRMSZ/2; i++ )
   {
      mlow[i+11] = low[i];
      mup[i+11] = up[i];
   }

   for( n=11,j=0; j<FRMSZ; n++,j+=2 )
   {
      out[j] = out[j+1] = 0.0;
      for( i=0; i<12; i++ )
      {
	 out[j] += 2 * cof[2*i] * ( mlow[n-i] - mup[n-i] );
	 out[j+1] += 2 * cof[(2*i)+1] * ( mlow[n-i] + mup[n-i] );
      }
   }

   return;
}
